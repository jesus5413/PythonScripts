import sys
import re

# getAddress
#
# Parameters
#   file - A pointer that points to the last point area of the file
#
# returns
#   returns a dictionary that contains the address of the customer
#
# Purpose
#   - To parse the file and store tha appropriate address and returns the address with in a dictionary


def getAddress (file):
    address = {'LINES': "", 'CITY': "", 'STATE': "", 'ZIP': ""}

    while True:  # traverses through the file
        inputine = file.readline()
        inputine = inputine.rstrip('\n')
        if inputine.find("ADDREND") == 0 or inputine.find(""):
            return address

        if inputine.find("LINE") == 0:  # Checks for lines
            if len(address['LINES']) >= 1:  # checls for the len of of elements in lines
                address['LINES'] = address['LINES'] + " " + inputine.split(' ', 1)[1]
            else:
                address['LINES'] = inputine.split(' ', 1)[1]

        if inputine.find("CITY") == 0:  # checks for citys
            address['CITY'] = inputine.split(' ', 1)[1]

        if inputine.find("STATE") == 0:  # checks for state
            address['STATE'] = inputine.split(' ', 1)[1]

        if inputine.find("ZIP") == 0:  # checks for zzip
            address['ZIP'] = inputine.split(' ', 1)[1]


# printAddress
#
# Parameters
#   addressD - a dictionary containing an address
#   addressNr - the nth address associated with the customer
# returns
#   n/a - just prints the address
#
# Purpose
#   - to print the address of the customer
def printAddress (addressD, addressNr):
    print("%d    %s"%(addressNr, addressD['LINES']))
    print("     %s,  %s %s \n"%(addressD['CITY'], addressD['STATE'], addressD['ZIP']))


def parseAddress(info):
    mainAddress = {'StreetNum': "",
                   'StreetType': "",
                   'Direction': "",
                   'AptNum': "",
                   'City': "",
                   'State': "",
                   'StrName': "",
                   'Zip': "",
                   'AdrLine': "" }

    mainAddress['City'] = info['CITY']
    mainAddress['State'] = info['STATE']
    mainAddress['Zip'] = info['ZIP']
    mainAddress['AdrLine'] = info['LINES']
    adrParse = info['LINES'].split()
    mainAddress['StreetNum'] = adrParse[0]
    adrParse.pop(0)
    if (len(adrParse) == 1):
        print(len(adrParse))
        mainAddress["StrName"] = ' '.join(adrParse).upper()
        return mainAddress

    adrParse, mainAddress['AptNum'] = getAptNumber(adrParse)

    if (len(adrParse) == 1):
        print(len(adrParse))
        mainAddress["StrName"] = ' '.join(adrParse).upper()
        return mainAddress

    adrParse, mainAddress['StreetType'] = getStreetType(adrParse)
    if (len(adrParse) == 1):
        print(len(adrParse))
        mainAddress["StrName"] = ' '.join(adrParse).upper()
        return mainAddress


    adrParse, mainAddress['Direction'] = getDirection(adrParse)

    if (len(adrParse) >= 1):
        print(len(adrParse))
        mainAddress["StrName"] = ' '.join(adrParse).upper()
        return mainAddress








    # print(adrParse)

    # print("------------------------------------------------------------------------"+ mainAddress['Direction'])

    return mainAddress;

def addressSyntaxException(info):
    if not info['LINES']:
        print("--------------------------------------------Address does not exist")

    else:
        address = info['LINES']
        strNum = address[0];
        if not strNum[0].isdecimal():
            print("----------------------------------------Error with street number")

    if not info['CITY']:
        print("--------------------------------------------There is no city")

    if not info['STATE']:
        print("--------------------------------------------There is no state")

    if not info['ZIP']:
        print("--------------------------------------------There is no zip")

    else:
        if len(info['ZIP']) < 5:
            print("----------------------------------------Zip is less than 5 digits")

def streetType(info):
    #standard types of street acronyms
    strType = {          "avenue":
                         ["av", "ave", "aven", "avenu",
                          "avn", "avnue", "avenue", "ave."],
                         "boulevard":
                         ["blvd", "blvd.", "boul", "boulevard", "boulv"],
                         "circle":
                         ["cir", "circ", "circl", "crcl", "crcle", "circle"],
                         "height":
                         ["ht", "height"],
                         "lane":
                         ["ln", "lane"],
                         "ridge":
                         ["rdg", "rdge", "ridge"],
                         "road":
                         ["rd", "road", "rd."],
                         "route":
                         ["rte", "route"],
                         "run":
                         ["run"],
                         "springs":
                         ["spgs", "spngs", "sprngs", "springs"],
                         "square":
                         ["square", "sq", "sq."],
                         "street":
                         ["strt", "st", "str", "street", "st."],
                         "trail":
                         ["trl", "trail"],
                         "terrace":
                         ["ter", "terr", "terrace"],
                         "valley":
                         ["vally", "vlly", "vly", "valley"],
                         "view":
                         ["vw", "view"],
                         "way":
                         ["wy", "way"]
            }

    for key in strType.keys():
        for value in strType[key]:
            if ''.join(sorted(info.lower())) == ''.join(sorted(value)):
                return key.upper()

    return ""


def getStreetType(parsedAddress):

    realStrType = ""
    for key in parsedAddress:
        strType = streetType(key)
        if strType != "":
            realStrType = strType.upper()
            i = parsedAddress.index(key)
            parsedAddress.pop(i)

    return parsedAddress, realStrType

def direction(info):

    direction = {             "east":
                              ["e", "east"],
                              "north":
                              ["n", "north", "n."],
                              "northeast":
                              ["ne", "n east", "north e", "northeast",
                               "north east"],
                              "northwest":
                              ["nw", "n west", "north w", "northwest",
                               "north west"],
                              "northsouth":
                              ["ns", "n south", "north s", "northsouth",
                               "north south"],
                              "south":
                              ["s", "south"],
                              "southeast":
                              ["se", "s east", "southeast"],
                              "southwest":
                              ["sw", "s west", "southwest", "s.w."],
                              "west":
                              ["w", "west", "w."]
                }

    for key in direction.keys():
        for value in direction[key]:
            if ''.join(value) == ''.join(info.lower()):
                return key.upper()

    return ""

def getDirection(parsedAddress):
    strDir = []
    tempPopList = []
    for key in parsedAddress:
        i = parsedAddress.index(key)
        temp = direction(key)

        if temp != "":
            if (i + 1) < len(parsedAddress):
                checker = parsedAddress[(i + 1)]

                if direction(checker) != "":
                    continue

            strDir.append(temp)
            tempPopList.append(i)

    strString = ''.join(strDir).lower()
    strString = direction(strString)
    tempPopList.reverse()

    for k in tempPopList:
        parsedAddress.pop(k)

    return parsedAddress, strString


def getAptNumber(parsedAddress):

    aptList = ["apartment", "apt", "nr", "#"]
    aptNmb = ""

    checker = False  # to get aptNmb

    for key in parsedAddress:
        if key.startswith("#"):

            if len(key) > 1:

                aptNmb = re.sub(r'\W', '', key)  # to get the apt number

                parsedAddress.pop(parsedAddress.index(key))
                break

            else:
                checker = True

        elif key.lower() in aptList:
            checker = True

        elif checker is True and key.lower() not in aptList:
            aptNmb = parsedAddress.pop(parsedAddress.index(key))
            break

    for key in aptList:
        for key2 in parsedAddress:
            if key2.lower() == key.lower():
                parsedAddress.remove(key2)

    return parsedAddress, aptNmb




